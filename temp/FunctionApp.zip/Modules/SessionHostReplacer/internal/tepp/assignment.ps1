﻿<#
# Example:
Register-PSFTeppArgumentCompleter -Command Get-Alcohol -Parameter Type -Name SessionHostReplacer.alcohol
#>